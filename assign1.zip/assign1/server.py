import socket

SERVER_PORT = 5050
SERVER_HOST = "0.0.0.0"  # Accept connections from all interfaces

def run_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((SERVER_HOST, SERVER_PORT))
    server_socket.listen(1)
    print(f"[SERVER] Listening on port {SERVER_PORT}...")

    while True:
        client_conn, client_addr = server_socket.accept()
        print(f"[SERVER] Connection from {client_addr}")

        data = client_conn.recv(1024).decode()
        if not data:
            print("[SERVER] No data received.")
            client_conn.close()
            continue

        try:
            user_name, client_number = data.split("::")
            client_number = int(client_number)
        except ValueError:
            print("[SERVER] Invalid data format.")
            client_conn.close()
            continue

        client_name = f"Client of {user_name}"
        server_name = f"Server of {user_name}"

        print(f"[SERVER] Communication with:")
        print(f" - Client Name: {client_name}")
        print(f" - Server Name: {server_name}")
        print(f" - Client Number: {client_number}")

        if not (1 <= client_number <= 100):
            print("[SERVER] Invalid number received. Shutting down.")
            client_conn.close()
            break

        server_number = 26  # Static number or use random.randint(1, 100)

        total = client_number + server_number
        print(f" - Server Number: {server_number}")
        print(f" - Sum: {total}\n")

        reply = f"{server_name}::{server_number}"
        client_conn.send(reply.encode())
        client_conn.close()

    server_socket.close()
    print("[SERVER] Socket closed.")

if __name__ == "__main__":
    run_server()

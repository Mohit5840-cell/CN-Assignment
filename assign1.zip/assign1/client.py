import socket

SERVER_IP = "127.0.0.1"  # Replace with actual server IP if needed
SERVER_PORT = 5050

def run_client():
    user_name = input("Enter your name: ").strip()
    if not user_name:
        print("Name cannot be empty.")
        return

    try:
        client_number = int(input("Enter an integer (1-100): "))
        if not (1 <= client_number <= 100):
            print("Invalid input. Must be between 1 and 100.")
            return
    except ValueError:
        print("Invalid input. Please enter an integer.")
        return

    client_name = f"Client of {user_name}"

    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((SERVER_IP, SERVER_PORT))

        message = f"{user_name}::{client_number}"
        client_socket.send(message.encode())

        data = client_socket.recv(1024).decode()
        if data:
            try:
                server_name, server_number = data.split("::")
                server_number = int(server_number)
            except ValueError:
                print("Invalid data format received.")
                return

            total = client_number + server_number
            print("\n--- Communication Summary ---")
            print(f"Client Name: {client_name}")
            print(f"Server Name: {server_name}")
            print(f"Client Number: {client_number}")
            print(f"Server Number: {server_number}")
            print(f"Sum: {total}")
        else:
            print("No response received.")

    except ConnectionError as e:
        print(f"Connection error: {e}")
    finally:
        client_socket.close()

if __name__ == "__main__":
    run_client()
